import "./App.css";
import CovidData from "./CovidData";
  
function App() {
  return <div className="App">
    <CovidData/>
  </div>;
}
  
export default App;